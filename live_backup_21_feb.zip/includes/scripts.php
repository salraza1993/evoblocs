<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" referrerpolicy="no-referrer"></script>
<!-- Swiper slider -->
<!-- <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script> -->
<script src="js/slick.js"></script>
<script src="js/main.js"></script>
